<header>
    <a href="/main.php">
        <img src="./img/basic/title.png" width="230px" height="60px">
    </a>
</header>